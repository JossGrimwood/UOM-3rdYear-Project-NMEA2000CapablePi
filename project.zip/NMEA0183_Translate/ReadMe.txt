


licensing:
com0com and associated installed binaries package with my application under the GPL license. credit to http://com0com.sourceforge.net/ see bin\readme.txt