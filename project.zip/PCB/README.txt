Cad files for Pi HAT
designed in designspark
